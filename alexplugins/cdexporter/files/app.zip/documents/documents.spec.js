'use strict';

describe('alexandriaCD.documents module', function() {

  beforeEach(module('alexandriaCD.documents'));

  describe('documents controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var documentsCtrl = $controller('DocumentsCtrl');
      expect(documentsCtrl).toBeDefined();
    }));

  });
});