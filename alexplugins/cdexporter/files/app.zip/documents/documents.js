'use strict';

angular.module('alexandriaCD.documents', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/documents', {
    templateUrl: 'document_list.html',
    controller: 'DocumentsCtrl'
  });
  $routeProvider.when('/document/:documentid', {
	  templateUrl: 'document_details.html',
	  controller: 'DocumentDetailCtrl'
  });
}])

.controller('DocumentsCtrl', ['$scope', 'DocumentService', function($scope, DocumentService) {
	$scope.documents = DocumentService.getDocuments();
}])
.controller('DocumentDetailCtrl', ['$scope', '$routeParams', '$uibModal', 'DocumentService', 'EventService',
                                    function($scope, $routeParams, $uibModal, DocumentService, EventService) {
	var documentId = $routeParams['documentid'];

	$scope.document = DocumentService.getDocument(documentId);
	DocumentService.addPdfPath($scope.document);
	$scope.documentFileRows = _.reduce(_.map($scope.document.file_infos, function(file_info) {
		DocumentService.addThumbnailPath(file_info);
		return file_info;
	}), function(rows, file_info) {
		var current_row = rows[rows.length-1];
		if (current_row.length == 3) {
			rows.push([]);
			current_row = rows[rows.length-1]
		};
		current_row.push(file_info);
		return rows;
	}, [[]])
	$scope.openDocumentFile = function(file_info) {
		DocumentService.addDisplayFilePath(file_info);
		$scope.selected_file_info = file_info;
		$uibModal.open({
			templateUrl: 'document_file_display.html',
		    controller: 'DocumentFileDisplayCtrl',
		    scope: $scope,
		    size: 'lg'
		});
		
	} 
	$scope.related_events = _.map($scope.document.related_events, function(relatedEventId) {
		return EventService.getEvent(relatedEventId);
	});
		

}])
.controller('DocumentFileDisplayCtrl', ['$scope', '$uibModalInstance',
                                        function($scope, $uibModalInstance) {
	$scope.close = $uibModalInstance.close;
	$scope.imagewidth = "100%";
	
}])
.service('DocumentService', [function() {
	return {
		getDocuments: function() {
			return alexandria.data.documents;
		},
		getDocument: function(documentId) {
			return _.find(alexandria.data.documents, function(document) {
				return document._id == documentId;
			})
		},
		addThumbnailPath: function(document) {
			var filename = this.createFilename(document, '.png')
			document.thumbnail = "alexandria/thumbnails/" + filename;
		},
		addDisplayFilePath: function(document) {
			var filename = this.createFilename(document, '.png')
			document.display_file = "alexandria/screen/" + filename;
		},
		addPdfPath: function(document) {
			var filename = this.createFilename(document, '.pdf')
			document.pdf = "alexandria/pdf/" + filename;
		},
		createFilename: function(document, extension) {
			var filename = document._id + '';
			while(filename.length < 8){
				filename = '0' + filename;
			}
			return filename + extension;
		}
	}
}]);