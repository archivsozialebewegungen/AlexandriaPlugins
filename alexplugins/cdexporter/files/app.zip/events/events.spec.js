'use strict';

describe('alexandriaCD.events module', function() {

  beforeEach(module('alexandriaCD.events'));

  describe('events controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var eventsCtrl = $controller('EventsCtrl');
      expect(eventsCtrl).toBeDefined();
    }));

  });
});