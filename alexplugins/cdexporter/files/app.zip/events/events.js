'use strict';

angular.module('alexandriaCD.events', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/events', {
    templateUrl: "event_list.html",
    controller: 'EventsCtrl'
  });
  $routeProvider.when('/event/:eventid', {
	templateUrl: "event_details.html",
	controller: 'EventDetailCtrl'
		  
  });	
}])

.filter('daterangedisplay', ['EventService', function(EventService) {
	
    return function(input) {
    	return EventService.formatDaterange(input);
    };
  }])

.controller('EventsCtrl', ['$scope', 'EventService', 'DTOptionsBuilder', 'DTColumnDefBuilder',
                           function($scope, EventService, DTOptionsBuilder, DTColumnDefBuilder) {
	$scope.dtOptions = DTOptionsBuilder.newOptions()
	$scope.dtColumnDefs = [DTColumnDefBuilder.newColumnDef(0).withOption("sType", "alexdate"),
	                       DTColumnDefBuilder.newColumnDef(1)];
	$scope.events = alexandria.data.events;
}])
.controller('EventDetailCtrl', ['$scope', '$routeParams', 'EventService', 'DocumentService',
                                function($scope, $routeParams, EventService, DocumentService) {
	var eventId = $routeParams['eventid'];
	$scope.event = EventService.getEvent(eventId);
	$scope.documentRows = _.reduce(_.map($scope.event.related_documents, function(documentId) {
		var document = DocumentService.getDocument(documentId);
		DocumentService.addThumbnailPath(document);
		return document;
	}), function(rows, document) {
		var current_row = rows[rows.length-1];
		if (current_row.length == 3) {
			rows.push([]);
			current_row = rows[rows.length-1]
		};
		current_row.push(document);
		return rows;
	}, [[]])
	$scope.related_events = _.map($scope.event.related_events, function(relatedEventId) {
		return EventService.getEvent(relatedEventId);
	});
	
	
}])
.service('EventService', [function() {
	return {
		getEvents: function() {
			return alexandria.data.events;
		},
		getEvent: function(eventId) {
			for (var i = 0; i < alexandria.data.events.length; i++) {
				if (alexandria.data.events[i]._id == eventId) {
					return alexandria.data.events[i];
				}
			}
		},
		months: ['', 'Januar', 'Februar', 'März', 'April',
	              'Mai', 'Juni', 'Juli', 'August', 'September',
	              'Oktober', 'November', 'Dezember'],
		formatDate: function(date) {
		    var display = '';
		    if (date._day) {
		    	display += date._day + ". ";
		    }
		    if (date._month) {
		    	display += this.months[date._month] + " ";
		    }
		    display += date._year;
		    return display
		},
		formatDaterange: function(daterange) {
	    	var display = this.formatDate(daterange.start_date)
	    	if (daterange.end_date) {
	    		display += " bis " + this.formatDate(daterange.end_date);
	    	}
	    	return display;
		}
	}
}]);