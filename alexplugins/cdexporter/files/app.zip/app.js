'use strict';

// Declare app level module which depends on views, and components
angular.module('alexandriaCD', [
  'ngRoute',
  'ngSanitize',
  'ui.bootstrap',
  'datatables',
  'alexandriaCD.start',
  'alexandriaCD.events',
  'alexandriaCD.documents'
])
.config(['$locationProvider', '$routeProvider', 
         function($locationProvider, $routeProvider) {
  $locationProvider.hashPrefix('!');
  $routeProvider.otherwise({redirectTo: '/start'});
  
}])
.run(['DTDefaultOptions', function(DTDefaultOptions) {
	var alexdateRe = /(\d{10})/;
	var alexdateToInt = function(alexdate) {
		var matchData = alexdateRe.exec(alexdate);
		return matchData[1]
	}
	$.fn.dataTableExt.oSort['alexdate-asc'] = function(x,y){
		var xint = alexdateToInt(x);
		var yint = alexdateToInt(y);
		return ((xint < yint) ? -1 : ((xint > yint) ?  1 : 0));
	}
	$.fn.dataTableExt.oSort['alexdate-desc'] = function(x,y){
		var xint = alexdateToInt(x);
		var yint = alexdateToInt(y);
		return ((xint < yint) ? 1 : ((xint > yint) ?  -1 : 0));
	}
	DTDefaultOptions.setLanguage({
	    "sEmptyTable":      "Keine Daten in der Tabelle vorhanden",
	    "sInfo":            "_START_ bis _END_ von _TOTAL_ Einträgen",
	    "sInfoEmpty":       "0 bis 0 von 0 Einträgen",
	    "sInfoFiltered":    "(gefiltert von _MAX_ Einträgen)",
	    "sInfoPostFix":     "",
	    "sInfoThousands":   ".",
	    "sLengthMenu":      "_MENU_ Einträge anzeigen",
	    "sLoadingRecords":  "Wird geladen...",
	    "sProcessing":      "Bitte warten...",
	    "sSearch":          "Suchen ",
	    "sZeroRecords":     "Keine Einträge vorhanden.",
	    "oPaginate": {
	        "sFirst":       "Erste",
	        "sPrevious":    "Zurück",
	        "sNext":        "Nächste",
	        "sLast":        "Letzte"
	    },
	    "oAria": {
	        "sSortAscending":  ": aktivieren, um Spalte aufsteigend zu sortieren",
	        "sSortDescending": ": aktivieren, um Spalte absteigend zu sortieren"
	    }
    });
}]);
