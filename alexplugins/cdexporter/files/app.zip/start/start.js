'use strict';

angular.module('alexandriaCD.start', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/start', {
    templateUrl: 'start.html',
    controller: 'TextCtrl'
  });
  $routeProvider.when('/impressum', {
	    templateUrl: 'impressum.html',
	    controller: 'TextCtrl'
	  });
}])
.controller('TextCtrl', ['$scope', function($scope) {
	$scope.pagecontent = alexandria.pagecontent;
}])
